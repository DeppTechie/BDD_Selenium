package pageObjects;

import org.openqa.selenium.By;

public class LaunchPageObject {

	
  public static By linkToFirstProduct = By.xpath("//div/a/img[@alt='Faded Short Sleeve T-shirts']");
  public static By linkToAddProduct  = By.xpath("//div/a[@class='button ajax_add_to_cart_button btn btn-default']");
	
  public static By continueButton  = By.xpath("//div[@class='button-container']/span[@class='continue btn btn-default button exclusive-medium']");
    
  public static By  linkToSecondProduct  = By.xpath("//div/a/img[@alt='Printed Dress']");
  
  public static By linkToAddProduct2 = By.xpath("//*[@data-id-product='3']");
  public static By CheckoutButton = By.xpath("//*[@class='button btn btn-default standard-checkout button-medium']");
  public static By FinalCheckOut = By.xpath("//*[@title='Proceed to checkout']");
  public static By UserId= By.id("email_create");
  public static By SubmitUser = By.id("SubmitCreate");
  public static By Mr = By.id("id_gender1");
  
  public static By UserFirstName =By.id("customer_firstname");
  public static By UserLastName =By.id("customer_lastname");
  public static By Password =By.id("passwd");
  
  public static By FirstName = By.id("firstname");
  public static By LastName= By.id("lastname");
  public static By Address= By.id("address1");
  public static By CityName =By.id("city");
  public static By StateName =By.id("id_state");
  public static By ZIP =By.id("postcode");
  public static By MobileNumber= By.id("phone_mobile");
  public static By Alias =By.id("alias");
  public static By SubmitInfo=By.id("submitAccount");
  public static By AddressConfirmation=By.xpath("//*[@name='processAddress']");
  public static By Terms = By.id("cgv");
  public static By Prepayment=By.xpath("//*[@name='processCarrier']");
  public static By PaymentMethod = By.className("bankwire");
  public static By FinalSubmission =By.xpath("//*[@class='button btn btn-default button-medium']");
  
} 