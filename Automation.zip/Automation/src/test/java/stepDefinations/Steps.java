package stepDefinations;

import org.junit.runner.RunWith;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import dataProvider.ConfigFileReader;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.cucumber.core.logging.Logger;
import io.cucumber.core.logging.LoggerFactory;
import io.cucumber.junit.Cucumber;
import pageObjects.LaunchPageObject;
import static stepDefinations.RegexUtils.*;
import java.util.concurrent.TimeUnit;
import static stepDefinations.Constants.*;
 
@SuppressWarnings("deprecation")
@RunWith(Cucumber.class)
public class Steps extends LaunchPageObject{
	
	static final Logger LOG = LoggerFactory.getLogger(Steps.class);

	WebDriver driver;
	ConfigFileReader configFileReader= new ConfigFileReader();;
	
    @Given("^I launch the Shopping Page$")
    public void i_launch_the_shopping_page() {
    	  
    	try {
   System.setProperty("webdriver.chrome.driver",  configFileReader.getValue("driverPath"));
    	driver = new ChromeDriver();
    	driver.manage().deleteAllCookies();
    	driver.get(configFileReader.getValue("url"));
    	driver.manage().window().maximize();
    	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    	}
    	
    	catch (Exception e)
    	
    	{LOG.debug("Debugging the Browser Launch",e);}
    }

    @When("^I add First Item to cart$")
    public void i_add_first_item_to_cart() throws Throwable {
   try {
    	WebElement a= driver.findElement(linkToFirstProduct);
    Actions action = new Actions(driver);
    action.moveToElement(a).perform();

    configFileReader.getValue("implicitlyWait");
    
    driver.findElement(linkToAddProduct).click();    
    WebDriverWait wait = new WebDriverWait(driver,10);
    WebElement continueshopping = wait.until(ExpectedConditions.elementToBeClickable(continueButton));
    continueshopping.click();
    LOG.info("User Added First Product");
   } catch (Exception e) {LOG.debug("Debugging the Addition of Product 1",e);}
    }
    	
   
    
    @When("^I add Second Item to cart$")
    public void i_add_second_item_to_cart() throws Throwable {
    try {	WebElement a1= driver.findElement(linkToSecondProduct);
	    Actions action1 = new Actions(driver);
	    action1.moveToElement(a1).perform();	 
	    configFileReader.getValue("implicitlyWait");
	    
	    driver.findElement(linkToAddProduct2).click();  
	    LOG.info("Second Item Slelection Successful");
    } catch (Exception e) {LOG.debug("Debugging the Second Selection");}
    }

    @Then("^I move to Review Page$")
    public void i_move_to_review_page() throws Throwable {
    	try {
    	WebDriverWait wait1 = new WebDriverWait(driver,10);
    	WebElement checkout = wait1.until(ExpectedConditions.elementToBeClickable(FinalCheckOut));   
	    checkout.click(); 
	    driver.findElement(CheckoutButton).click();  	      
	    LOG.info("User Added Second Product");
    	} catch (Exception e) {
    		LOG.debug("Debugging the First Check Out Before Review Page");
    	}
    }

    @When("^I enter the userID$")
    public void i_enter_the_userid() throws Throwable { 
	   try {
    	driver.findElement(UserId).sendKeys(generate(EMAIL));
    	driver.findElement(SubmitUser).click();
    	
    	LOG.info("User enetered the EMail ID");
    
	   } catch (Exception e) {LOG.debug("I am debugging");}

    }

    @When("^I Fill PersonalInfo Form$")
    
    public void i_fill_personalinfo_form() throws Throwable {
  
    	try {
WebDriverWait wait2 = new WebDriverWait(driver,60);
WebElement  maleRadioBtn = wait2.until(ExpectedConditions.elementToBeClickable (Mr)); 
 maleRadioBtn.click();	   
	   
	    driver.findElement(UserFirstName).sendKeys(configFileReader.getValue(USER_FIRST_NAME_KEY));
	    driver.findElement(UserLastName).sendKeys(configFileReader.getValue(USER_LAST_NAME_KEY));
	    driver.findElement(Password).sendKeys(configFileReader.getValue(PASSWORD_KEY));
	    driver.findElement(FirstName).sendKeys(configFileReader.getValue(FIRSTNAME_KEY));
	    driver.findElement(LastName).sendKeys(configFileReader.getValue(LASTNAME_KEY));
	    driver.findElement(Address).sendKeys(configFileReader.getValue(ADDRESS_KEY));
	    driver.findElement(CityName).sendKeys(configFileReader.getValue(CITY_KEY));
	    Select dropdown= new Select(driver.findElement(StateName));
	    dropdown.selectByIndex(2);
	    driver.findElement(ZIP).sendKeys(configFileReader.getValue(ZIP_KEY));
	    driver.findElement(MobileNumber).sendKeys(configFileReader.getValue(MOBILE_KEY));
	    driver.findElement(Alias).sendKeys(configFileReader.getValue(ALIAS_KEY));
	    driver.findElement(SubmitInfo).click();   	    
  
	    LOG.info("User Application submitted succesfully");
    	} catch (Exception e) {
    		LOG.debug("Debbuging User Application details");
    	}
	    
    }

    @When("^I confirm Shipping Address$")
    public void i_confirm_shipping_address() throws Throwable {
    try {
    	driver.findElement(AddressConfirmation).click();
    	driver.findElement(Terms).click();	   
	    driver.findElement(Prepayment).click();
	    LOG.info("Sipping address Confirmed by User");
    } catch (Exception e) 	{
    	
    	LOG.debug("Debugging the Shipping Address Section");
    	
    }
    }
    @Then("^I confirm the payment$")
    public void i_confirm_the_payment() throws Throwable {
     try {	
    	driver.findElement(PaymentMethod).click();
     } catch (Exception e) {
    	 
    	LOG.debug("Debugging the Payment method");
     }
    }

    @And("^Finally Place Order$")
    public void finally_place_order() throws Throwable {
      	try {
    	driver.findElement(FinalSubmission).click();      	
    	LOG.info("ORDER PLACED SUCCESSFULLY");
      	} catch (Exception e) {
      		
      		LOG.debug("Debugging Order Placing");
      	}
      	}
    

@And("^I Close the window$")
public void I_Close_the_window() throws Throwable {
	//Keeping the Browser open for a while before quiting

	Thread.sleep(10000);
	
	driver.quit();
}}